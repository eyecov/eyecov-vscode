
# Covflux

**Coverage in your editor. Coverage for your AI tools.**

Covflux reads coverage artifacts (PHPUnit HTML, LCOV, etc.) and turns them into a runtime coverage model used by:

- the editor
- developer tooling
- AI assistants via MCP

Works in **VS Code**, **Cursor**, and compatible editors.

---

# Coverage in the editor

### Line highlighting (default)

![Coverage lines](images/coverage-lines.png)

Coverage appears directly in the editor.

- 🟢 covered lines
- 🔴 uncovered lines
- ⚪ uncoverable lines

---

### Optional gutter markers

![Coverage gutter](images/coverage-gutter.png)

Enable additional gutter markers for fast scanning.

```
covflux.showGutterCoverage
```

---

### Status bar coverage

![Coverage status](images/coverage-statusbar.png)

The current file coverage is shown in the editor status bar.

Example:

```
49.0% (25/51)
```

---

# Supported coverage formats

Currently supported:

- PHPUnit HTML
- LCOV

Formats are resolved in order.

Example generators:

```
phpunit --coverage-html coverage-html
```

or

```
vitest run --coverage
```

---

# AI Coverage via MCP

Covflux exposes coverage through a built‑in **MCP server**.

Available tools:

- coverage_file
- coverage_line_tests
- coverage_path
- coverage_project
- coverage_test_priority

This allows AI tools to answer questions such as:

- Which files need tests most?
- Which tests cover this line?
- What areas have the lowest coverage?

---

# Configuration

Optional `.covflux.json`:

```json
{
  "formats": [
    { "type": "phpunit-html", "path": "coverage-html" },
    { "type": "lcov", "path": "coverage/lcov.info" }
  ]
}
```

Formats are tried in order. The first matching format is used.

---

# Development

Install:

```
npm install
```

Compile:

```
npm run compile
```

Run extension host:

```
F5
```

---

# License

MIT
